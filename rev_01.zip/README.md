# NVMemProg --- Non-Volatile Memory Programmer

This design is an universal memory programmer with USB 2.0 (high-speed mode) interface
to a host PC, 48 independent universal pin drivers, 2 power lines (VCC, VPP) and an ability to generate
arbitrary digital waveforms with the maximum speed of 24MHz.


**WARNING!**
There are missing components on the pcb, due to a mistake, which was
corrected only in the schematics. See TODO for more information.

## Design Description
#### Block Diagram
TODO

#### Description
TODO

## EDA Tools
TODO

#### Simulation
TODO

## Firmware
...

## Host PC Software
...

## Benchmark
TODO

## License
This design is licensed under CERN OHL v.1.2. See the LICENSE file for the full text of the license.
